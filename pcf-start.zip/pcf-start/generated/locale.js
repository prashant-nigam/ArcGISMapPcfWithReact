"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.translateA = exports.translate = exports.configureLocale = void 0;
const path = require("path");
const fs = require("fs");
let diagnosticMessages = {};
let diagnosticMessagesEn = {};
async function configureLocale(config) {
    if (config.directory === '') {
        return Promise.reject('E_Unspecified_Directory');
    }
    if (config.diagnosticFileName === '') {
        return Promise.reject('E_Unspecified_Diagnostic_FileName');
    }
    if (config.locale === '') {
        return Promise.reject('E_Unspecified_Locale');
    }
    if (config.runtime !== 'node' && config.runtime !== 'browser') {
        return Promise.reject('E_Unsupported_Runtime');
    }
    const matchResult = /^([a-z]+)([_\-]([a-z]+))?$/.exec(config.locale.toLowerCase());
    if (!matchResult) {
        return Promise.reject('E_Unsupported_Locale');
    }
    const language = matchResult[1];
    const territory = matchResult[3];
    let result = await trySetLanguageAndTerritory(config, language, territory);
    if (!result) {
        // Fallback to language only
        result = await trySetLanguageAndTerritory(config, language, undefined);
    }
    if (result && language !== 'en') {
        // If a non english language was successfully loaded, then also load 'en' as a fallback
        // for strings that may not have been translated yet.
        let filePath = path.join(config.directory, 'en', config.diagnosticFileName);
        const enFallbackStrings = await loadLocalizedStrings(config, filePath);
        if (enFallbackStrings) {
            diagnosticMessagesEn = JSON.parse(enFallbackStrings);
        }
    }
    else {
        // Fallback to en
        result = await trySetLanguageAndTerritory(config, 'en', undefined);
    }
    if (!result) {
        return Promise.reject('E_Locale_Configuration_Error');
    }
    return result;
}
exports.configureLocale = configureLocale;
function translate(key) {
    if (diagnosticMessages[key]) {
        return diagnosticMessages[key];
    }
    else {
        return diagnosticMessagesEn[key];
    }
}
exports.translate = translate;
function translateA(key, args) {
    let format = diagnosticMessages[key];
    if (!format) {
        format = diagnosticMessagesEn[key];
    }
    return format.replace(/{(\d+)}/g, (_match, index) => '' + assertDefined(args[+index]));
}
exports.translateA = translateA;
async function trySetLanguageAndTerritory(config, language, territory) {
    let filePath = path.join(config.directory, language);
    if (territory) {
        filePath = filePath + '-' + territory;
    }
    filePath = path.join(filePath, config.diagnosticFileName);
    const fileContent = await loadLocalizedStrings(config, filePath);
    if (fileContent) {
        diagnosticMessages = JSON.parse(fileContent);
        return Promise.resolve(true);
    }
    else {
        return Promise.resolve(false);
    }
}
function loadLocalizedStrings(config, filePath) {
    return new Promise((resolve) => {
        if (config.runtime === 'browser') {
            const request = new XMLHttpRequest();
            request.onreadystatechange = () => {
                if (request.readyState === XMLHttpRequest.DONE) {
                    if (request.status === 200) {
                        return resolve(request.responseText);
                    }
                    else {
                        return resolve(undefined);
                    }
                }
            };
            request.open('GET', filePath, true);
            request.send();
        }
        else {
            if (!fs.existsSync(filePath)) {
                return resolve(undefined);
            }
            let fileContents = fs.readFileSync(filePath).toString();
            return resolve(fileContents);
        }
    });
}
function assertDefined(value, _message) {
    if (value === undefined || value === null) {
        throw new Error('E_Arg_Mismatch');
    }
    return value;
}
