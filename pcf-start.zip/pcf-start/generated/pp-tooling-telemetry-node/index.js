"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryConstants = exports.AppTelemetryUtility = exports.AppTelemetryConfigUtility = exports.AppInsightsConfigUtility = void 0;
// This module represents types with parallels in the BatchedTelemetry libraries found in the CRM.DevToolsCore repo.
exports.AppInsightsConfigUtility = require("./AppInsightsConfigUtility");
__exportStar(require("./AppInsightsResource"), exports);
__exportStar(require("./AppInsightsResourceProvider"), exports);
exports.AppTelemetryConfigUtility = require("./AppTelemetryConfigUtility");
exports.AppTelemetryUtility = require("./AppTelemetryUtility");
exports.TelemetryConstants = require("./TelemetryConstants");
__exportStar(require("./TelemetryUserSettingsFileProvider"), exports);
__exportStar(require("./interfaces"), exports);
