"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnvironmentVariableNames = exports.PropertyNames = void 0;
// This module represents types with parallels in the BatchedTelemetry libraries found in the CRM.DevToolsCore repo.
exports.PropertyNames = require("./PropertyNames");
exports.EnvironmentVariableNames = require("./EnvironmentVariableNames");
