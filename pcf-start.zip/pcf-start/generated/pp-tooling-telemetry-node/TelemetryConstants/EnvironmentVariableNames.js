"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PpToolsTelemetryDeveloperMode = exports.PpToolsAutomationAgent = exports.PpToolsTelemetryDataBoundary = exports.PpToolsTelemetryOptOut = void 0;
// This file should match the constants found in Microsoft.PowerPlatform.Tooling.BatchedTelemetry.TelemetryConstants.PropertyNames
// See: https://dev.azure.com/dynamicscrm/OneCRM/_git/CRM.DevToolsCore?path=/src/GeneralTools/BatchedTelemetry/BatchedTelemetry/TelemetryConstants.cs&version=GBmaster&line=31&lineEnd=32&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents
exports.PpToolsTelemetryOptOut = "PP_TOOLS_TELEMETRY_OPTOUT";
exports.PpToolsTelemetryDataBoundary = "PP_TOOLS_TELEMETRY_DATA_BOUNDARY";
exports.PpToolsAutomationAgent = "PP_TOOLS_AUTOMATION_AGENT";
exports.PpToolsTelemetryDeveloperMode = "PP_TOOLS_TELEMETRY_DEVELOPER_MODE";
