"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserSettingsFromSharedInstall = exports.createGlobalTelemetryEnvironment = void 0;
const os = require("node:os");
const path = require("node:path");
const process = require("node:process");
const uuid = require("uuid");
const AppTelemetryUtility_1 = require("./AppTelemetryUtility");
const TelemetryConstants_1 = require("./TelemetryConstants");
const TelemetryUserSettingsFileProvider_1 = require("./TelemetryUserSettingsFileProvider");
function createGlobalTelemetryEnvironment(getEnvironmentVariable = getEnvironmentVariableFromProcess) {
    return {
        optOut: (0, AppTelemetryUtility_1.parseBooleanEnvironmentVariable)(getEnvironmentVariable(TelemetryConstants_1.EnvironmentVariableNames.PpToolsTelemetryOptOut)),
        developerMode: (0, AppTelemetryUtility_1.parseBooleanEnvironmentVariable)(getEnvironmentVariable(TelemetryConstants_1.EnvironmentVariableNames.PpToolsTelemetryDeveloperMode)),
        dataBoundary: getEnvironmentVariable(TelemetryConstants_1.EnvironmentVariableNames.PpToolsTelemetryDataBoundary),
        automationAgent: getEnvironmentVariable(TelemetryConstants_1.EnvironmentVariableNames.PpToolsAutomationAgent),
    };
}
exports.createGlobalTelemetryEnvironment = createGlobalTelemetryEnvironment;
function getEnvironmentVariableFromProcess(name) {
    return process.env[name];
}
function getUserSettingsFromSharedInstall(logger) {
    const userSettingsPath = path.join(getAppDataPath(), "Microsoft", "PowerAppsCli", "usersettings.json");
    const userSettingsProvider = new TelemetryUserSettingsFileProvider_1.TelemetryUserSettingsFileProvider(userSettingsPath);
    return getCurrentUserSettingsOrDefault(userSettingsProvider, logger);
}
exports.getUserSettingsFromSharedInstall = getUserSettingsFromSharedInstall;
function getAppDataPath() {
    const platform = os.platform();
    switch (platform) {
        case "darwin":
            return "~/Library/";
        case "linux":
            return `${process.env.HOME}/.config/`;
        case "win32":
            return process.env.LOCALAPPDATA;
        default:
            throw new Error(`Platform "${platform}" is not currently supported`);
    }
}
function getCurrentUserSettingsOrDefault(provider, logger) {
    try {
        return provider.GetCurrent();
    }
    catch (error) {
        logger?.error(`[pp-tooling-telemetry-node]: ITelemetryUserSettingsProvider.GetCurrent threw unexpected error. Returning new user settings. Error: ${error}`);
        return {
            uniqueId: uuid.v4(),
            telemetryEnabled: true,
        };
    }
}
