"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppInsightsResource = void 0;
class AppInsightsResource {
    constructor(connectionString, dataBoundary) {
        this.connectionString = connectionString;
        this.dataBoundary = dataBoundary;
        if (!connectionString)
            throw new Error("Connection string is required.");
        if (dataBoundary === "")
            throw new Error("dataBoundary cannot be an empty string.");
        const firstParameter = this.connectionString.split(";")[0];
        const name = firstParameter.split("=", 2)[0];
        if (name !== "InstrumentationKey")
            throw new Error("Connection string must start with InstrumentationKey=...");
        this.instrumentationKey = firstParameter.split("=", 2)[1];
    }
}
exports.AppInsightsResource = AppInsightsResource;
