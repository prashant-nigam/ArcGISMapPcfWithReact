"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerCommonFinalTelemetryProcessors = exports.configureTelemetryClient = exports.setupAndStartAppInsights = void 0;
const appInsights = require("applicationinsights");
const AppTelemetryUtility_1 = require("./AppTelemetryUtility");
function setupAndStartAppInsights(appInsightsResourceProvider, environment) {
    const appInsightsResource = appInsightsResourceProvider.GetAppInsightsResourceForDataBoundary(environment.dataBoundary);
    appInsights
        .setup(appInsightsResource.connectionString)
        // suppress confusing DNS/http warnings if AI endpoints are not reachable
        .setInternalLogging(false, false)
        .setAutoCollectExceptions(false)
        .start();
}
exports.setupAndStartAppInsights = setupAndStartAppInsights;
function configureTelemetryClient(aiClient, productName, productVersion, sessionId, environment, userSettings) {
    if (!productName)
        throw new Error("productName must be specified.");
    if (!productVersion)
        throw new Error("productVersion must be specified.");
    if (!(0, AppTelemetryUtility_1.isSupportedAgentProductVersion)(productVersion))
        throw new Error(`productVersion '${productVersion}' is not a supported version format.`);
    if (!sessionId)
        throw new Error("sessionId must be specified.");
    aiClient.config.disableAppInsights = environment.optOut ?? !(userSettings.telemetryEnabled ?? true);
    // aka: ClientAppTelemetryInitializer.cs
    aiClient.context.tags[aiClient.context.keys.userId] = userSettings.uniqueId;
    aiClient.context.tags[aiClient.context.keys.cloudRole] = productName;
    aiClient.context.tags[aiClient.context.keys.cloudRoleInstance] = "#####";
    aiClient.context.tags[aiClient.context.keys.applicationVersion] = productVersion;
    aiClient.context.tags[aiClient.context.keys.sessionId] = sessionId;
}
exports.configureTelemetryClient = configureTelemetryClient;
function registerCommonFinalTelemetryProcessors(aiClient, environment, logger) {
    if (logger && !!environment.developerMode) {
        aiClient.addTelemetryProcessor((envelope, context) => logTelemetryItem(logger, envelope, context));
    }
}
exports.registerCommonFinalTelemetryProcessors = registerCommonFinalTelemetryProcessors;
function logTelemetryItem(logger, envelope, _context) {
    if (!envelope.data || !logger)
        return true; // Ignore when data doesn't exist
    const telemetryType = appInsights.Contracts.baseTypeToTelemetryType(envelope.data.baseType);
    switch (telemetryType) {
        case appInsights.Contracts.TelemetryType.Request:
            {
                const data = envelope.data.baseData;
                logger.info(`[pp-tooling-telemetry-node] Processing telemetry item of type '${envelope.data.baseType}'. name: ${data.name}, responseCode: ${data.responseCode}`);
            }
            break;
        case appInsights.Contracts.TelemetryType.Event:
            {
                const data = envelope.data.baseData;
                logger.info(`[pp-tooling-telemetry-node] Processing telemetry item of type '${envelope.data.baseType}'. name: ${data.name}`);
            }
            break;
        case appInsights.Contracts.TelemetryType.Exception:
            {
                const data = envelope.data.baseData;
                logger.info(`[pp-tooling-telemetry-node] Processing telemetry item of type '${envelope.data.baseType}'. problemId: '${data.problemId}'`);
            }
            break;
        default:
            logger.info(`[pp-tooling-telemetry-node] Processing telemetry item of type '${envelope.data.baseType}'`);
            break;
    }
    return true;
}
