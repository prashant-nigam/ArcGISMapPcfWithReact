"use strict";
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppInsightsResourceProvider = void 0;
class AppInsightsResourceProvider {
    constructor(defaultResource, ...additionalResources) {
        this.defaultResource = defaultResource;
        this._allResources = new Map();
        additionalResources.forEach((r) => {
            if (!r.dataBoundary)
                throw new Error("One or more of the additionalResources are missing a value for the dataBoundary.");
            this._allResources.set(r.dataBoundary, r);
        });
        if (defaultResource.dataBoundary && !this._allResources.has(defaultResource.dataBoundary)) {
            this._allResources.set(defaultResource.dataBoundary, defaultResource);
        }
    }
    GetAppInsightsResourceForDataBoundary(dataBoundary) {
        if (dataBoundary) {
            const match = this._allResources.get(dataBoundary);
            if (match) {
                return match;
            }
        }
        return this.defaultResource;
    }
}
exports.AppInsightsResourceProvider = AppInsightsResourceProvider;
