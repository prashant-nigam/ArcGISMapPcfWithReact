"use strict";
// Copyright (C) Microsoft Corporation. All rights reserved.
Object.defineProperty(exports, "__esModule", { value: true });
exports.pcfAppInsightsResourceProvider = void 0;
const pp_tooling_telemetry_node_1 = require("../pp-tooling-telemetry-node");
exports.pcfAppInsightsResourceProvider = new pp_tooling_telemetry_node_1.AppInsightsResourceProvider(
/* appi-dpxt-prod-us-pcf */ new pp_tooling_telemetry_node_1.AppInsightsResource("InstrumentationKey=1916902c-0e0c-4208-ba6b-7d7aa64b32e4;IngestionEndpoint=https://westus2-2.in.applicationinsights.azure.com/;LiveEndpoint=https://westus2.livediagnostics.monitor.azure.com/"), 
/* appi-dpxt-prod-eu-pcf */ new pp_tooling_telemetry_node_1.AppInsightsResource("InstrumentationKey=ef48d5d3-9e81-405a-bc03-0766796c460c;IngestionEndpoint=https://westeurope-5.in.applicationinsights.azure.com/;LiveEndpoint=https://westeurope.livediagnostics.monitor.azure.com/", "EU"));
