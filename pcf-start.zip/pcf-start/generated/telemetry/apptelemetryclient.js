"use strict";
// Copyright (C) Microsoft Corporation. All rights reserved.
Object.defineProperty(exports, "__esModule", { value: true });
exports.BuildSource = exports.TelemetryEvent = exports.AppTelemetryClient = exports.setupAppInsightsAndClient = void 0;
const appInsights = require("applicationinsights");
const uuid_1 = require("uuid");
const pp_tooling_telemetry_node_1 = require("../pp-tooling-telemetry-node");
const customtelemetryconfiguration_1 = require("./customtelemetryconfiguration");
function setupAppInsightsAndClient(productName, productVersion, environment, logger) {
    if (!productName)
        throw new Error("productName must be specified.");
    if (!productVersion)
        throw new Error("productVersion must be specified.");
    logger = logger ?? console; // Default to global console
    const devLogger = environment.developerMode ? logger : undefined;
    const appInsightsResourceProvider = customtelemetryconfiguration_1.pcfAppInsightsResourceProvider;
    const userSettings = pp_tooling_telemetry_node_1.AppTelemetryConfigUtility.getUserSettingsFromSharedInstall(logger);
    const sessionId = (0, uuid_1.v4)();
    devLogger?.warn(`[AppTelemetryClient] SessionId: '${sessionId}'. UserId: ${userSettings.uniqueId}; productVersion: '${productVersion}'`);
    pp_tooling_telemetry_node_1.AppInsightsConfigUtility.setupAndStartAppInsights(appInsightsResourceProvider, environment);
    const aiClient = appInsights.defaultClient;
    pp_tooling_telemetry_node_1.AppInsightsConfigUtility.configureTelemetryClient(aiClient, productName, productVersion, sessionId, environment, userSettings);
    // Placeholder: Add any app-custom telemetry processors
    pp_tooling_telemetry_node_1.AppInsightsConfigUtility.registerCommonFinalTelemetryProcessors(aiClient, environment, logger);
    return new AppTelemetryClient(aiClient, logger);
}
exports.setupAppInsightsAndClient = setupAppInsightsAndClient;
class AppTelemetryClient {
    constructor(aiClient, logger) {
        this._logger = logger;
        this._client = aiClient;
    }
    trackEvent(telemetry) {
        try {
            this._client.trackEvent(telemetry);
        }
        catch (error) {
            /* don't fail pcf-* due to telemetry errors */
            this.reportSwallowedError("trackEvent", error);
        }
    }
    trackException(telemetry) {
        try {
            this._client.trackException(telemetry);
        }
        catch (error) {
            /* don't fail pcf-* due to telemetry errors */
            this.reportSwallowedError("trackException", error);
        }
    }
    trackRequest(telemetry) {
        try {
            this._client.trackRequest(telemetry);
        }
        catch (error) {
            /* don't fail pcf-* due to telemetry errors */
            this.reportSwallowedError("trackRequest", error);
        }
    }
    flush() {
        try {
            this._client.flush();
        }
        catch (error) {
            /* don't fail pcf-* due to telemetry errors */
            this.reportSwallowedError("flush", error);
        }
    }
    reportSwallowedError(methodName, error) {
        this._logger?.warn(`[AppTelemetryClient] unexpected error occured in method '${methodName}': ${error}`);
    }
}
exports.AppTelemetryClient = AppTelemetryClient;
var TelemetryEvent;
(function (TelemetryEvent) {
    TelemetryEvent[TelemetryEvent["Start"] = 0] = "Start";
    TelemetryEvent[TelemetryEvent["End"] = 1] = "End";
    TelemetryEvent[TelemetryEvent["StartExecutingVerb"] = 2] = "StartExecutingVerb";
    TelemetryEvent[TelemetryEvent["EndExecutingVerb"] = 3] = "EndExecutingVerb";
})(TelemetryEvent = exports.TelemetryEvent || (exports.TelemetryEvent = {}));
var BuildSource;
(function (BuildSource) {
    BuildSource[BuildSource["VisualStudio"] = 0] = "VisualStudio";
    BuildSource[BuildSource["MSBuild"] = 1] = "MSBuild";
    BuildSource[BuildSource["NPM"] = 2] = "NPM";
})(BuildSource = exports.BuildSource || (exports.BuildSource = {}));
