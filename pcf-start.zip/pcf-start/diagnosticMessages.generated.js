"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.strings = void 0;
function diag(code, category, key, message) {
    return { code, category, key, message };
}
/* tslint:disable:max-line-length */
/* tslint:disable:quotemark */
exports.strings = {
    loading_harness: diag(1002, "Info", "loading_harness", "Loading control harness..."),
    loading_control: diag(1003, "Info", "loading_control", "Loading control..."),
    data_inputs: diag(1004, "Info", "data_inputs", "Data Inputs"),
    property: diag(1005, "Info", "property", "Property"),
    value: diag(1006, "Info", "value", "Value"),
    type: diag(1007, "Info", "type", "Type"),
    error_parse_resource_string: diag(1008, "Error", "error_parse_resource_string", "Error parsing resource '{0}'"),
    data_outputs: diag(1009, "Info", "data_outputs", "Data Outputs"),
    resource_file_loaded: diag(1010, "Error", "resource_file_loaded", "Resource file '{0}' loaded."),
    error_resource_load: diag(1011, "Error", "error_resource_load", "Failed to load resource '{0}'"),
    error_resource_type_not_supported: diag(1012, "Error", "error_resource_type_not_supported", "Resource '{0}' not loaded because {1} is not supported."),
    unknown_property_usage: diag(1013, "Error", "unknown_property_usage", "Property has an unknown value for the usage attribute"),
    unrecognized_type_group: diag(1014, "Error", "unrecognized_type_group", "Property references an unknown type-group '{0}'"),
    property_missing_type: diag(1015, "Error", "property_missing_type", "Property has neither type-of nor type-group attribute"),
    error_parsing_control_manifest: diag(1016, "Error", "error_parsing_control_manifest", "Manifest Parsing Error: Cannot parse ControlManifest.xml."),
    error_http_get_resource: diag(1017, "Error", "error_http_get_resource", "GET resource '{0}' returned with status {1}"),
    invoke_method: diag(1018, "Info", "invoke_method", "Invoked method {0} on {1} interface."),
    function_parameters: diag(1019, "Info", "function_parameters", "Parameters"),
    message: diag(1020, "Info", "message", "Message"),
    details: diag(1021, "Info", "details", "Details"),
    error_code: diag(1022, "Info", "error_code", "Error Code"),
    apply: diag(1023, "Info", "apply", "Apply"),
    choose_column: diag(1024, "Info", "choose_column", "Choose a Column"),
    choose_type: diag(1025, "Info", "choose_type", "Choose a Type"),
    error_read_file: diag(1026, "Error", "error_read_file", "Failed to read file {0}"),
    error_parse_file: diag(1027, "Error", "error_parse_file", "Failed to parse file {0}"),
    row: diag(1028, "Info", "row", "Row"),
    context_inputs: diag(1029, "Info", "context_inputs", "Context Inputs"),
    form_factor: diag(1030, "Info", "form_factor", "Form Factor"),
    column: diag(1031, "Info", "column", "Column"),
    web: diag(1032, "Info", "web", "Web"),
    tablet: diag(1033, "Info", "tablet", "Tablet"),
    phone: diag(1034, "Info", "phone", "Phone"),
    unknown: diag(1035, "Info", "unknown", "Unknown"),
    aria_label_data_file: diag(1036, "Info", "aria_label_data_file", "select a file for {0}, current file: {1}"),
    control_container_width: diag(1037, "Info", "control_container_width", "Component Container Width"),
    control_container_height: diag(1038, "Info", "control_container_height", "Component Container Height"),
    no_file_chosen: diag(1039, "Info", "no_file_chosen", "no file chosen"),
    select_a_file: diag(1040, "Info", "select_a_file", "Select a file"),
    only_numbers_allowed: diag(1041, "Info", "only_numbers_allowed", "Only positive whole numbers allowed"),
    out_of_range: diag(1042, "Info", "out_of_range", "Value out of range: {0} to {1}"),
    use_ISO_format: diag(1043, "Info", "use_ISO_format", "Use ISO format"),
    harness_header: diag(1044, "Info", "harness_header", "PowerApps component framework Test Environment"),
    enable_local_storage: diag(1045, "Info", "enable_local_storage", "Please enable localStorage in your browser https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API if you want to preserve customized inputs."),
    local_storage_exceeds_quota: diag(1046, "Info", "local_storage_exceeds_quota", "Reached the maximum size of localStorage https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API - clearing all previously stored user inputs."),
    local_storage_parse_error: diag(1047, "Error", "local_storage_parse_error", "Could not parse values in localStorage https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API. Please avoid manually editing values in localStorage."),
    unsupported_platform_action: diag(1066, "Error", "unsupported_platform_action", "unsupported action-type value {0}")
};
