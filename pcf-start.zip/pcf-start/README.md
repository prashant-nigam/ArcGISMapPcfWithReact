| **Harness for PCF (PowerApps Component Framework) controls** |
|---	|

## Overview

This package contains the scripts required to test and debug a custom PowerApps Component Framework (PCF) control for Microsoft PowerApps on your local development PC.
The scripts are designed to be used in conjunction with the Microsoft Power Platform CLI tool, which is separately available via an MSI installer.

Please visit the publicly available [documentation for the Microsoft Power Platform CLI tool](https://docs.microsoft.com/en-us/powerapps/developer/component-framework/create-custom-controls-using-pcf) to learn more.
You can also install the Power Platform CLI via our pac CLI [VS Code extension](https://aka.ms/PowerPlatformCLI).

**Without Microsoft Power Platform CLI tool this package should only be used for reference purposes.**

## Release Notes:

1.39.3:
- Updated ESLint devDependencies to v9

1.38.3:
- No changes

1.36.3:
- Change minimum supported node engine to >= 16. If lower version is still used, use version 1.35.1 of pcf-scripts.  Recommended version of Node.js is >= 18.
- Change build target to `es2020` from `es5`.
- Remove es6 shim

1.35.1:
- No changes

1.32.5: 
- Updated dependencies.

1.14.2:
- support for React(virtual) and Fluent UI code components using platform libraries.

1.13.6:
- pcf-start no longer uses browser-sync (replacing the no longer maintained live-server npm package)
    this also addresses the npm audit warnings on npm install (caused by outdated live-server)

1.9.4
- local test harness: npm run start also works now on MacOS and Linux

1.8.6:
- Gracefully handle telemetry connection errors

1.7.4:
- pcf-start: fixed uuid/v4 package not found
- Various accessibility fixes
- Harness only allows positive numbers for component container height & width in context inputs.

1.4.1:
- Support for 'common-property' in ControlManifest and test harness
- Harness now uses default height & width settings, if defined in the manifest

1.3.1:
- Fix crash in debug harness for Boolean/TwoOptions field data

1.2.6:
- Localization updates
- Updated the version of PCF shipped with the debug harness to avoid null reference exceptions that only arise when loading a virtual control in a non-XRM scenario

1.1.6:
- Previous context and data inputs in the test harness now can be preserved across sessions

1.0.6:
- Various accessibility improvements in the control harness
- Control harness supports loading default property values defined by the default-value attribute

0.4.3:
- Added optional watch capabilities to the control harness (use 'npm start watch')
- Added anonymous telemetry to pcf; to opt out use PowerApps CLI, see:
[PowerApps CLI telemetry](https://docs.microsoft.com/en-us/powerapps/developer/component-framework/get-powerapps-cli#microsoft-powerapps-cli-telemetry)
- More accessibility support and fixes

0.3.4:
- Accessibility fixes
- Debug harness supports data-set inputs
- Debug harness can consume CSV for data-set inputs
- Debug harness allows selecting different form factors (Unknown, Web, Tablet, and Phone)
- Debug harness UI is aligned with PowerApps GUI theme

0.2.71:
- Test harness is updated to use the latest version of the PowerApps Component Framework
- PCF UI is localized for: English, French, German, Japanese, Spanish

0.2.59:
- Support dataset controls in the local control harness with default mock data. This enables visualization and debugging of a dataset control outside of CDS environment
- Added initialization of control context attributes with default values in the local control harness

0.1:
- Initial set of capabilities for custom control development using the PowerApps Component Framework (PCF).
